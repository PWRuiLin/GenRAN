import glob
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
from RFHN import config as c
from natsort import natsorted
def to_rgb(image):
    rgb_image = Image.new("RGB", image.size)
    rgb_image.paste(image)
    return rgb_image

class Hinet_Dataset(Dataset):
    def __init__(self, transforms_=None, mode="train"):

        self.transform = transforms_
        self.mode = mode
        if self.mode == "train":
            # TRAIN SETTING
            if c.Dataset_TRAIN_mode == 'CelebA-HQ':
                self.TRAIN_PATH = c.TRAIN_PATH_CelebAHQ
                self.format_train = 'jpg'
                print('TRAIN DATASET is CelebA-HQ')

            if c.Dataset_TRAIN_mode == 'CelebA':
                self.TRAIN_PATH = c.TRAIN_PATH_CelebA
                self.format_train = 'jpg'
                print('TRAIN DATASET is CelebA')

            # train
            self.files = natsorted(sorted(glob.glob(self.TRAIN_PATH + "/*." + self.format_train)))

        if self.mode == "valid":
            # VAL SETTING
            if c.Dataset_VALID_mode == 'CelebA-HQ':
                self.VALID_PATH = c.VALID_PATH_CelebAHQ
                self.format_valid = 'jpg'
                print('VALID DATASET is CelebA-HQ')

            if c.Dataset_VALID_mode == 'CelebA':
                self.VALID_PATH = c.VALID_PATH_CelebA
                self.format_valid = 'jpg'
                print('VALID DATASET is CelebA')

            # valid
            self.files = natsorted(sorted(glob.glob(self.VALID_PATH + "/*." + self.format_valid)))

        if self.mode == "test":
            # TEST SETTING
            if c.Dataset_TEST_mode == 'CelebA-HQ':
                self.TEST_PATH = c.TEST_PATH_CelebAHQ
                self.format_test = 'jpg'
                print('TEST DATASET is CelebA-HQ')

            if c.Dataset_TEST_mode == 'CelebA':
                self.TEST_PATH = c.TEST_PATH_CelebA
                self.format_test = 'jpg'
                print('TEST DATASET is CelebA')

            if c.Dataset_TEST_mode == 'LFW':
                self.TEST_PATH = c.TEST_PATH_LFW
                self.format_test = 'jpg'
                print('TEST DATASET is LFW')

            if c.Dataset_TEST_mode == 'FFHQ':
                self.TEST_PATH = c.TEST_PATH_FFHQ
                self.format_test = 'png'
                print('TEST DATASET is FFHQ')
            if c.Dataset_TEST_mode == 'AGE_ADULTS':
                self.TEST_PATH = c.TEST_PATH_AGE_ADULTS
                self.format_test = 'png'
                print('TEST DATASET is AGE_ADULTS')

            if c.Dataset_TEST_mode == 'experiment1_8':
                self.TEST_PATH = c.TEST_PATH_experiment1_8
                self.format_test = 'jpg'
                print('TEST DATASET is experiment1_8')

            if c.Dataset_TEST_mode == 'experiment1_2':
                self.TEST_PATH = c.TEST_PATH_experiment1_2
                self.format_test = 'jpg'
                print('TEST DATASET is experiment1_2')

            if c.Dataset_TEST_mode == 'experiment2':
                self.TEST_PATH = c.TEST_PATH_experiment2
                self.format_test = 'jpg'
                print('TEST DATASET is experiment2')

            if c.Dataset_TEST_mode == 'experiment3':
                self.TEST_PATH = c.TEST_PATH_experiment3
                self.format_test = 'png'
                print('TEST DATASET is experiment3')
            # valid
            self.files = natsorted(sorted(glob.glob(self.TEST_PATH + "/*." + self.format_test)))
    def __getitem__(self, index):
        try:
                image = Image.open(self.files[index])
                image = to_rgb(image)
                item = self.transform(image)
                return item

        except:
            return self.__getitem__(index + 1)

    def __len__(self):
        return len(self.files)


if c.Dataset_VALID_mode == 'CelebA-HQ':
    cropsize_valid = c.cropsize_valid_CelebAHQ
if c.Dataset_VALID_mode == 'CelebA':
    cropsize_valid = c.cropsize_valid_CelebA
if c.Dataset_VALID_mode == 'LFW':
    cropsize_valid = c.cropsize_valid_LFW

transform = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomVerticalFlip(),
    T.RandomCrop(c.cropsize_train),
    T.ToTensor()
])

transform_valid = T.Compose([
    T.CenterCrop(cropsize_valid),
    T.ToTensor(),
])

transform_test = T.Compose([
    T.Resize((1024,1024)),
    T.ToTensor(),
])
# Training data loader
trainloader = DataLoader(
    Hinet_Dataset(transforms_=transform, mode="train"),
    batch_size=c.batch_size_train,
    shuffle=False,
    pin_memory=False,
    num_workers=0,
    drop_last=True
)
# Valid data loader
validloader = DataLoader(
    Hinet_Dataset(transforms_=transform_valid, mode="valid"),
    batch_size=c.batchsize_valid,
    shuffle=False,
    pin_memory=False,
    num_workers=0,
    drop_last=True
)
# Test data loader
testloader = DataLoader(
    Hinet_Dataset(transforms_=transform_test, mode="test"),
    batch_size=c.batchsize_test,
    shuffle=False,
    pin_memory=False,
    num_workers=0,
    drop_last=True
)

import os
import cv2
def dataset(A, B, C):
    dataset_A_path = A
    dataset_B_path = B
    dataset_C_path = C
    #确保保存结果的目录存在
    os.makedirs(dataset_C_path, exist_ok=True)
    # 遍历数据集A
    for i, filename in enumerate(os.listdir(dataset_A_path)):
        img_A = cv2.imread(os.path.join(dataset_A_path, filename))
        new_filename = '{:05d}.png'.format(2 * i + 1)
        cv2.imwrite(os.path.join(dataset_C_path, new_filename), img_A)
    # 遍历数据集B
    for i, filename in enumerate(os.listdir(dataset_B_path)):
        img_B = cv2.imread(os.path.join(dataset_B_path, filename))
        new_filename = '{:05d}.png'.format(2 * i +2)
        cv2.imwrite(os.path.join(dataset_C_path, new_filename), img_B)
    print('OK')

A = './Dataset/AGE_ADULTS/fake/'
B = './Dataset/AGE_ADULTS/real/'
C = './Dataset/AGE_ADULTS/test/'
# dataset(A, B, C)
if __name__ == '__main__':
    print('len(trainloader)=',len(trainloader))
    print('len(validloader)=', len(validloader))
    print('len(testloader)=',len(testloader))
    # for i_batch, data in enumerate(trainloader):
    #     print("trainloader成功")
    # for i_batch, data in enumerate(testloader):
    #     print("testloader成功")


# class Hinet_Dataset(Dataset):
#     def __init__(self, transforms_=None, mode="train"):
#
#         self.transform = transforms_
#         self.mode = mode
#         if mode == 'train':
#             # train
#             self.files = natsorted(sorted(glob.glob(c.TRAIN_PATH + "/*." + c.format_train)))
#         else:
#             # test
#             self.files = sorted(glob.glob(c.VALID_PATH + "/*." + c.format_valid))
#
#     def __getitem__(self, index):
#         try:
#             image = Image.open(self.files[index])
#             image = to_rgb(image)
#             item = self.transform(image)
#             return item
#
#         except:
#             return self.__getitem__(index + 1)
#
#     def __len__(self):
#         if self.mode == 'shuffle':
#             return max(len(self.files_cover), len(self.files_secret))
#         else:
#             return len(self.files)
# transform = T.Compose([
#     T.RandomHorizontalFlip(),
#     T.RandomVerticalFlip(),
#     T.RandomCrop(c.cropsize),
#     T.ToTensor()
# ])
# transform_val = T.Compose([
#     T.CenterCrop(c.cropsize_val),
#     T.ToTensor(),
# ])
# # Training data loader
# trainloader = DataLoader(
#     Hinet_Dataset(transforms_=transform, mode="train"),
#     batch_size=c.batch_size_train,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# # Test data loader
# testloader = DataLoader(
#     Hinet_Dataset(transforms_=transform_val, mode="val"),
#     batch_size=c.batchsize_valid,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# if __name__ == '__main__':
#     print("main")
#     print('len(trainloader)=',len(trainloader))
#     print('len(testloader)=',len(testloader))





#
#
# class Hinet_Dataset(Dataset):
#     def __init__(self, transforms_=None, mode="train"):
#
#         self.transform = transforms_
#         self.mode = mode
#         if mode == 'fake_train':
#             # train
#             self.files = natsorted(sorted(glob.glob(c.FAKE_TRAIN_PATH + "/*." + c.format_train)))
#         elif mode == 'real_train':
#             # train
#             self.files = natsorted(sorted(glob.glob(c.REAL_TRAIN_PATH + "/*." + c.format_train)))
#         elif mode == 'fake_valid':
#             # train
#             self.files = natsorted(sorted(glob.glob(c.FAKE_VALID_PATH + "/*." + c.format_valid)))
#         elif mode == 'real_valid':
#             # train
#             self.files = natsorted(sorted(glob.glob(c.REAL_VALID_PATH + "/*." + c.format_valid)))
#         elif mode == 'fake_test':
#             # train
#             self.files = natsorted(sorted(glob.glob(c.FAKE_TEST_PATH + "/*." + c.format_test)))
#         elif mode == 'real_test':
#             # train
#             self.files = natsorted(sorted(glob.glob(c.REAL_TEST_PATH + "/*." + c.format_test)))
#         else:
#             self.files = []
#
#     def __getitem__(self, index):
#         try:
#             image = Image.open(self.files[index])
#             image = to_rgb(image)
#             item = self.transform(image)
#             return item
#         except:
#             return torch.empty(0)
#         # except:
#         #     return self.__getitem__(index + 1)
#
#     def __len__(self):
#         # if self.mode == 'shuffle':
#         #     return max(len(self.files_cover), len(self.files_secret))
#         # else:
#         #     return len(self.files)
#         return len(self.files)
#
# transform_train = T.Compose([
#     T.RandomHorizontalFlip(),
#     T.RandomVerticalFlip(),
#     T.RandomCrop(c.cropsize),
#     T.ToTensor()
# ])
#
# transform_valid = T.Compose([
#     T.CenterCrop(c.cropsize_val),
#     T.ToTensor(),
# ])
# transform_test = T.Compose([
#     T.ToTensor(),
# ])
# fake_train_dataset = Hinet_Dataset(transforms_=transform_train, mode="fake_train")
# real_train_dataset = Hinet_Dataset(transforms_=transform_train, mode="real_train")
# fake_valid_dataset = Hinet_Dataset(transforms_=transform_valid, mode="fake_valid")
# real_valid_dataset = Hinet_Dataset(transforms_=transform_valid, mode="real_valid")
# fake_test_dataset = Hinet_Dataset(transforms_=transform_test, mode="fake_test")
# real_test_dataset = Hinet_Dataset(transforms_=transform_test, mode="real_test")
# # Training data loader
# trainloaderfake = DataLoader(
#     fake_train_dataset,
#     batch_size=c.batch_size_train,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# trainloaderreal = DataLoader(
#     real_train_dataset,
#     batch_size=c.batch_size_train,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# # Valid data loader
# validloaderfake = DataLoader(
#     fake_valid_dataset,
#     batch_size=c.batchsize_valid,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# validloaderreal = DataLoader(
#     real_valid_dataset,
#     batch_size=c.batchsize_valid,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# # Test data loader
# testloaderfake = DataLoader(
#     fake_test_dataset,
#     batch_size=c.batchsize_test,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# testloaderreal = DataLoader(
#     real_test_dataset,
#     batch_size=c.batchsize_test,
#     shuffle=False,
#     pin_memory=True,
#     num_workers=0,
#     drop_last=True
# )
# if __name__ == '__main__':
#     # # print("main")
#     print('len(trainloaderreal)=',len(trainloaderreal))
#     print('len(trainloaderfake)=', len(trainloaderfake))
#     # print('len(validloaderreal)=',len(validloaderreal))
#     # print('len(testloaderreal)=', len(testloaderreal))
#     for i_batch, data in enumerate(trainloaderreal):
#         print('i_batch_trainloader=',i_batch)
#         print('data=',data.shape)
#         print("trainloader成功")

# import os
# import cv2
# dataset_A_path = '/home/WRL/WRL/DeepMIH/HiNet/Dataset/CelebA-HQ/fake_train/'
# dataset_B_path = '/home/WRL/WRL/DeepMIH/HiNet/Dataset/CelebA-HQ/real_train/'
# dataset_C_path = '/home/WRL/WRL/DeepMIH/HiNet/Dataset/CelebA-HQ/train/'
# #确保保存结果的目录存在
# os.makedirs(dataset_C_path, exist_ok=True)
# # 遍历数据集A
# for i, filename in enumerate(os.listdir(dataset_A_path)):
#     print('a')
#     img_A = cv2.imread(os.path.join(dataset_A_path, filename))
#     new_filename = '{:05d}.jpg'.format(2 * i + 1)
#     cv2.imwrite(os.path.join(dataset_C_path, new_filename), img_A)
# # 遍历数据集B
# for i, filename in enumerate(os.listdir(dataset_B_path)):
#     img_B = cv2.imread(os.path.join(dataset_B_path, filename))
#     new_filename = '{:05d}.jpg'.format(2 * i +2)
#     cv2.imwrite(os.path.join(dataset_C_path, new_filename), img_B)
# #