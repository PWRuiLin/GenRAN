import cv2
import math
import time
import torch
import torch.nn
import torch.optim
import torchvision
from torch.autograd import Variable
import numpy as np
from RFHN.models.model import *
import RFHN.config as c
from RFHN import jpeg
import RFHN.models.Unet_common as common

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# from attack.FGSM.fgsm import FGSM_test
def guide_loss(output, bicubic_image):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(output, bicubic_image)
    return loss.to(device)

def load(net, optim, name):
    state_dicts = torch.load(name)
    network_state_dict = {k:v for k,v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    try:
        optim.load_state_dict(state_dicts['opt'])
    except:
        print('Cannot load optimizer for some reason or other')
def gauss_noise(shape):
    noise = torch.zeros(shape).cuda()
    for i in range(noise.shape[0]):
        noise[i] = torch.randn(noise[i].shape).cuda()
    return noise
def calculate_psnr(img1, img2):
    img1 = img1.detach().cpu().numpy().astype(np.float64)
    img2 = img2.detach().cpu().numpy().astype(np.float64)
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    PIXEL_MAX = 1  # 1      RGB:255
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))



def RFHN(anonymization_face, protected_face, model = 'model_141_best.pth'):
    net = Model()
    net.cuda()
    init_model(net)
    net = torch.nn.DataParallel(net, device_ids=c.device_ids)
    params_trainable = (list(filter(lambda p: p.requires_grad, net.parameters())))
    optim = torch.optim.Adam(params_trainable, lr=c.lr, betas=c.betas, eps=1e-6, weight_decay=c.weight_decay)
    weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, c.weight_step, gamma=c.gamma)
    # load(c.MODEL_PATH + c.suffix +'_{}'.format(num)+'.pt')  #pth   pt
    # load(net, optim, c.MODEL_PATH + c.suffix + '_{}'.format(num) + '_best.pth')  # pth   pt
    load(net, optim, c.MODEL_PATH + model)  # pth   pt
    net.eval()
    dwt = common.DWT()
    iwt = common.IWT()
    with torch.no_grad():
        anonymization_face = anonymization_face.to(device)
        protected_face = protected_face.to(device)
        anonymization_face_input = dwt(anonymization_face)
        protected_face_input = dwt(protected_face)
        input_img = torch.cat((anonymization_face_input, protected_face_input), 1)
        #################
        #    forward:   #
        #################
        forward_img = net(input_img)
        output_anonymized_face = forward_img.narrow(1, 0, 4 * c.channels_in)
        output_z = forward_img.narrow(1, 4 * c.channels_in, forward_img.shape[1] - 4 * c.channels_in)
        anonymized_face = iwt(output_anonymized_face)

        backward_z = gauss_noise(output_z.shape)
        # print(backward_z.shape)
        lost_r = iwt(output_z)
        # random_z = iwt(backward_z)
        random_z = iwt(backward_z)
        #################
        #   backward:   #
        #################
        T_recover_start = time.time()
        # print(backward_z.shape)
        # random_z = torch.zeros(1, 3, 256, 256).to(device)
        # backward_z = dwt(random_z)
        # anonymized_face_noise = noise(anonymized_face)
        # anonymized_face_noise_dwt = dwt(anonymized_face_noise)

        output_rev = torch.cat((output_anonymized_face, backward_z), 1)
        bacward_img = net(output_rev, rev=True)
        protected_face_rev = bacward_img.narrow(1, 4 * c.channels_in, bacward_img.shape[1] - 4 * c.channels_in)
        protected_face_rev = iwt(protected_face_rev)
        anonymization_rev = bacward_img.narrow(1, 0, 4 * c.channels_in)
        anonymization_rev = iwt(anonymization_rev)
        T_recover_end = time.time()
        T_recover = T_recover_end - T_recover_start
        print('T_recover', T_recover)
        resi_anonymized_anonymization = (anonymized_face - anonymization_face) * 40
        resi_protected_rev_protected = (protected_face_rev - protected_face) * 40

        return anonymization_face, protected_face, anonymized_face, protected_face_rev, anonymization_rev, lost_r, random_z, resi_anonymized_anonymization, resi_protected_rev_protected, T_recover
