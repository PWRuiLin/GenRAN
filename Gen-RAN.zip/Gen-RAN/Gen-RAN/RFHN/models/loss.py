import torch
import torch.nn as nn
import torch.optim
from model import *
import torch.nn.functional as F
import skimage
import pytorch_ssim
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
ssim_loss = pytorch_ssim.SSIM(window_size=11)
def gauss_noise(shape):
    noise = torch.zeros(shape).cuda()
    for i in range(noise.shape[0]):
        noise[i] = torch.randn(noise[i].shape).cuda()
    return noise

def guide_loss(output, bicubic_image):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(output, bicubic_image)
    return loss.to(device)
def reconstruction_loss(rev_input, input):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(rev_input, input)
    return loss.to(device)
def low_frequency_loss(ll_input, gt_input):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(ll_input, gt_input)
    return loss.to(device)


def low_frequency_loss_MAE(ll_input, gt_input):
    loss_fn = torch.nn.L1Loss(reduce=True, size_average=False)
    loss = loss_fn(ll_input, gt_input)
    return loss.to(device)
def low_frequency_loss_MSE(ll_input, gt_input):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(ll_input, gt_input)
    return loss.to(device)
def low_frequency_loss_SmoothMAE(ll_input, gt_input):
    loss_fn = torch.nn.SmoothL1Loss(reduce=True, size_average=False)
    loss = loss_fn(ll_input, gt_input)
    return loss.to(device)
def low_frequency_loss_SmoothMSE(ll_input, gt_input):
    loss_fn = SmoothMSELoss(0.04)
    loss = loss_fn(ll_input, gt_input)
    return loss.to(device)
class SmoothMSELoss(nn.Module):
    def __init__(self, smoooth_param):
        super(SmoothMSELoss, self).__init__()
        self.smoooth_param = smoooth_param# 平滑参数（smooth_param）的值取决于你对模型预测与真实值之间的差异有多敏感以及你希望在过渡到MSE损失时的平滑程度。
        # 较小的smooth_param值会导致更快地从平滑损失过渡到MSE损失，即使在差异较小的情况下也会使用较接近MSE的损失。这样可以使模型更加关注具体的差异。
        # 较大的smooth_param值将导致更慢地过渡到MSE损失，即使在差异较大的情况下仍然使用平滑损失。这样可以使模型对异常值或噪声更具鲁棒性，减少其对损失的影响。
        # 如果smooth_param的值设置得太小，平滑损失的影响可能会很小，而如果设置得太大，模型可能会过于关注整体趋势而忽略细节。
        self.mse_loss = torch.nn.MSELoss(reduce=True, size_average=False)
    def forward(self, input, tarfet):
        mse_loss = self.mse_loss(input, tarfet)
        smooth_mse_loss = torch.where(mse_loss < self.smoooth_param, 0.5 * mse_loss ** 2, torch.abs((mse_loss) - 0.5 * self.smoooth_param))
        loss = torch.mean(smooth_mse_loss)
        return loss


class L1_Charbonnier_loss(torch.nn.Module):
    """L1 Charbonnierloss."""
    def __init__(self):
        super(L1_Charbonnier_loss, self).__init__()
        self.eps = 1e-6

    def forward(self, X, Y):
        diff = torch.add(X, -Y)
        error = torch.sqrt(diff * diff + self.eps)
        loss = torch.mean(error)
        return loss

class GWLoss(nn.Module):
    """Gradient Weighted Loss"""
    def __init__(self, reduction='mean'):
        super(GWLoss, self).__init__()
        self.w = 4
        self.reduction = reduction
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float)
        self.weight_x = nn.Parameter(data=sobel_x, requires_grad=False)
        self.weight_y = nn.Parameter(data=sobel_y, requires_grad=False)
    def forward(self, x1, x2):
        b, c, w, h = x1.shape
        weight_x = self.weight_x.expand(c, 1, 3, 3).type_as(x1)
        weight_y = self.weight_y.expand(c, 1, 3, 3).type_as(x1)
        Ix1 = F.conv2d(x1, weight_x, stride=1, padding=1, groups=c)
        Ix2 = F.conv2d(x2, weight_x, stride=1, padding=1, groups=c)
        Iy1 = F.conv2d(x1, weight_y, stride=1, padding=1, groups=c)
        Iy2 = F.conv2d(x2, weight_y, stride=1, padding=1, groups=c)
        dx = torch.abs(Ix1 - Ix2)
        dy = torch.abs(Iy1 - Iy2)
        # loss = torch.exp(2*(dx + dy)) * torch.abs(x1 - x2)
        loss = (1 + self.w * dx) * (1 + self.w * dy) * torch.abs(x1 - x2)
        if self.reduction == 'mean':
            return torch.mean(loss)
        else:
            return torch.sum(loss)
def MSE_loss(rev_input, input):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(rev_input, input)
    return loss.to(device)