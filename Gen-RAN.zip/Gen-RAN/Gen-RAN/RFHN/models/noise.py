import torch.nn as nn
from RFHN.models.noise_layers import *
class Noise(nn.Module):
    def __init__(self, layers):
        super(Noise, self).__init__()
        for i in range(0, len(layers)):
            # print(layers[i])
            layers[i] = eval(layers[i])
        self.noise = nn.Sequential(*layers)
    def forward(self, image_and_cover):
        noised_image = self.noise(image_and_cover)
        return noised_image