import numpy as np
import torch
import torch.nn as nn
import cv2
from torch.autograd import Variable
class Gaussian_blur(nn.Module):
    def __init__(self, size):
        super(Gaussian_blur, self).__init__()
        self.size = size
    def forward(self, image_and_cover):
        image = image_and_cover
        image = image.cpu().detach().numpy() * 255
        image = image.transpose((0, 2, 3, 1))
        for idx in range(image.shape[0]):
            encoded_image = image[idx]
            noise_image = cv2.GaussianBlur(encoded_image, (self.size, self.size), 0)
            noise_image = torch.from_numpy(noise_image.transpose((2, 0, 1))).type(torch.FloatTensor).cuda()
            if (idx == 0):
                batch_noise_image = noise_image.unsqueeze(0)
            else:
                batch_noise_image = torch.cat((batch_noise_image, noise_image.unsqueeze(0)), 0)  # batch*H*W*C
        batch_noise_image = Variable(batch_noise_image, requires_grad=True).cuda()  # batch*C*H*W
        return batch_noise_image / 255