import torch
import torch.nn as nn
from torch.autograd import Variable
import skimage

class Gaussian_noise(nn.Module):

	def __init__(self, Standard_deviation):
		super(Gaussian_noise, self).__init__()
		self.Standard_deviation = Standard_deviation

	def forward(self, image_and_cover):
		image = image_and_cover
		batch_encoded_image = image.cpu().detach().numpy() * 255
		batch_encoded_image = batch_encoded_image.transpose((0, 2, 3, 1))
		for idx in range(batch_encoded_image.shape[0]):
			encoded_image = batch_encoded_image[idx]
			noise_image = skimage.util.random_noise(encoded_image, mode='gaussian', clip=False,
													var=(self.Standard_deviation) ** 2)
			noise_image = torch.from_numpy(noise_image.transpose((2, 0, 1))).type(torch.FloatTensor).cuda()
			if (idx == 0):
				batch_noise_image = noise_image.unsqueeze(0)
			else:
				batch_noise_image = torch.cat((batch_noise_image, noise_image.unsqueeze(0)), 0)  # batch*H*W*C
		batch_noise_image = Variable(batch_noise_image, requires_grad=True).cuda()  # batch*C*H*W
		return batch_noise_image / 255

# class Gaussian_noise(nn.Module):
#
# 	def __init__(self, var, mean=0):
# 		super(Gaussian_noise, self).__init__()
# 		self.var = var
# 		self.mean = mean
#
# 	def gaussian_noise(self, image, mean, var):
# 		noise = torch.Tensor(np.random.normal(mean, var ** 0.5, image.shape)).to(image.device)
# 		out = image + noise
# 		return out
#
# 	def forward(self, image_and_cover):
# 		image, cover_image = image_and_cover
# 		return self.gaussian_noise(image, self.mean, self.var)
