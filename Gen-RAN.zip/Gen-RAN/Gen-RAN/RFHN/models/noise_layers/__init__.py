import random


def get_random_float(float_range: [float]):
	return random.random() * (float_range[1] - float_range[0]) + float_range[0]


def get_random_int(int_range: [int]):
	# print(random.randint(int_range[0], int_range[1]))
	return random.randint(int_range[0], int_range[1])


from .identity import Identity
from .gaussian_noise import Gaussian_noise
from .gaussian_blur import Gaussian_blur
from .jpeg import Jpeg, JpegSS, JpegMask, JpegTest, Jpeg_compression

