from train import train_loss

train_loss(lamda_guide=1, lamda_reconstruction=4, lamda_low_frequency=1, DWT='Yes', low_frequency_loss = 'SmoothMSE',
           model_name='model_DWTYes_SmoothMSE0.04', image_name='DWTYes_SmoothMSE.png')




# model_DWTYes_SmoothMSE0.1
# processed Ok
#  secret | model=model_DWTYes_SmoothMSE_best.pth | PSNR_AVE=56.045466656916986 | SSIM_AVE=0.9994521722226741
#  cover | model=model_DWTYes_SmoothMSE_best.pth | PSNR_AVE=48.40601893122023 | SSIM_AVE=0.9934630434626992
#  secret | model=model_DWTYes_SmoothMSE_best.pth | MAE_AVE=0.08816492080688479 | RMSE_AVE=0.43459501588519833
#  cover | model=model_DWTYes_SmoothMSE_best.pth | MAE_AVE=0.5550824642181396 | RMSE_AVE=0.9773801181504101
#
#
#  0.05
#  secret | model=model_DWTYes_SmoothMSE0.2_best.pth | PSNR_AVE=57.51253763962795 | SSIM_AVE=0.999561601447982
#  cover | model=model_DWTYes_SmoothMSE0.2_best.pth | PSNR_AVE=48.45186945062609 | SSIM_AVE=0.9934994215746531
#  secret | model=model_DWTYes_SmoothMSE0.2_best.pth | MAE_AVE=0.07333513259887696 | RMSE_AVE=0.3708863888491827
#  cover | model=model_DWTYes_SmoothMSE0.2_best.pth | MAE_AVE=0.5227208614349366 | RMSE_AVE=0.9756182835538




