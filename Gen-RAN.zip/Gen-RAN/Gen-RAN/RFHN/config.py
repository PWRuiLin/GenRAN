# Super parameters
clamp = 2.0
channels_in = 3
log10_lr = -4.5   #4.5
lr = 10 ** log10_lr
epochs = 2000                                                                                                           #lamda 2000
weight_decay = 1e-5
init_scale = 0.01

lamda_guide = 1
lamda_Lssim = 0.3; lamda_Lchab = 0.65; lamda_Lgwl = 0.05#; lamda_mse=1
lamda_reconstruction = 3    #10
lamda_low_frequency = 1     #10
device_ids = [0]

# Train:
batch_size_train = 16         #16
cropsize_train = 128
betas = (0.5, 0.999)
weight_step = 500
gamma = 0.5

# ValID:
batchsize_valid = 2
shuffle_val = False
val_freq = 1
cropsize_valid_CelebAHQ = 128
cropsize_valid_CelebA = 128
cropsize_valid_LFW = 128
#TEST
batchsize_test = 2

# Dataset
Dataset_TRAIN_mode = 'CelebA-HQ'    # CelebA / CelebA-HQ
Dataset_VALID_mode = 'CelebA-HQ'    # CelebA / CelebA-HQ
Dataset_TEST_mode = 'CelebA-HQ'     # CelebA-HQ jpg/ CelebA jpg/ LFW jpg/ FFHQ png/ AGE_ADULTS / experiment1_8 experiment1_2 png/ experiment2 / experiment3 png

TRAIN_PATH_CelebAHQ = './Dataset/CelebA-HQ/train/'
TRAIN_PATH_CelebA = './Dataset/CelebA/train/'
VALID_PATH_CelebAHQ = './Dataset/CelebA-HQ/valid/'
VALID_PATH_CelebA = './Dataset/CelebA/valid/'
TEST_PATH_CelebAHQ = './Dataset/CelebA-HQ/test/'
TEST_PATH_CelebA = './Dataset/CelebA/test/'
TEST_PATH_FFHQ = './Dataset/FFHQ/test/'
TEST_PATH_LFW = './Dataset/LFW/test/'
TEST_PATH_AGE_ADULTS = './Dataset/AGE_ADULTS/test/'
TEST_PATH_experiment1_8 = './Dataset/experiments/experiment1/8/'
TEST_PATH_experiment1_2 = './Dataset/experiments/experiment1/2/'
TEST_PATH_experiment2 = './Dataset/experiments/experiment2/'
TEST_PATH_experiment3 = './Dataset/experiments/experiment3/'

# FAKE_TRAIN_PATH = './Dataset/CelebA-HQ/fake_train/'
# REAL_TRAIN_PATH = './Dataset/CelebA-HQ/real_train/'
# FAKE_VALID_PATH = './Dataset/CelebA-HQ/fake_test/'
# REAL_VALID_PATH = './Dataset/CelebA-HQ/real_test/'
# FAKE_TEST_PATH  = './Dataset/CelebA-HQ/fake_test/'
# REAL_TEST_PATH  = './Dataset/CelebA-HQ/real_test/'
# TRAIN_PATH = r"/home/WRL/WRL/DeepMIH/HiNet/Dataset/CelebA-HQ/train/"
# VALID_PATH = r"/home/WRL/WRL/DeepMIH/HiNet/Dataset/CelebA-HQ/test/"
# TEST_PATH  = r"/home/WRL/WRL/DeepMIH/HiNet/Dataset/CelebA-HQ/test/"
# format_train = 'jpg'
# format_valid = 'jpg'
# format_test = 'jpg'

# Display and logging:
loss_display_cutoff = 2.0
loss_names = ['L', 'lr']
silent = False
live_visualization = False
progress_bar = False


# Saving checkpoints:
loss = 'MSE' # MAE MSE
MODEL_PATH = '/home/WRL/WRL/RFA-Net/RFHN/model/test_model/'

checkpoint_on_error = False
SAVE_freq = 1

IMAGE_TEST_PATH = './image/test/'
IMAGE_TEST_PATH_cover = IMAGE_TEST_PATH + 'cover/'
IMAGE_TEST_PATH_secret = IMAGE_TEST_PATH + 'secret/'
IMAGE_TEST_PATH_steg = IMAGE_TEST_PATH + 'steg/'
IMAGE_TEST_PATH_secret_rev = IMAGE_TEST_PATH + 'secret-rev/'
IMAGE_TEST_PATH_resi_cover = IMAGE_TEST_PATH + 'resi-cover/'
IMAGE_TEST_PATH_resi_secret = IMAGE_TEST_PATH + 'resi-secret/'
IMAGE_TEST_PATH_output_r = IMAGE_TEST_PATH + 'output-r/'
IMAGE_TEST_PATH_backward_z = IMAGE_TEST_PATH + 'backward-z/'


IMAGE_TRAIN_PATH = './image/train/'
IMAGE_TRAIN_PATH_cover = IMAGE_TRAIN_PATH + 'cover/'
IMAGE_TRAIN_PATH_secret = IMAGE_TRAIN_PATH + 'secret/'
IMAGE_TRAIN_PATH_steg = IMAGE_TRAIN_PATH + 'steg/'
IMAGE_TRAIN_PATH_secret_rev = IMAGE_TRAIN_PATH + 'secret-rev/'
# Load:
suffix = 'model.pt'#model_checkpoint_00001.pt model_BEST

tain_next = False
trained_epoch = 0
