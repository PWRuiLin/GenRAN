import base64
import urllib
import requests
import json
import time
import cv2
import os
# API_KEY = "ZLOKtERseZG0aFZwEcKtgxvg"
# SECRET_KEY = "Dxo7EQyZ35aMdZxEKPXQ646vRF28Z3ND"
API_KEY = "nC88NflfRLTRdhKrh50lAGaz"
SECRET_KEY = "WrBYD3FzONgTk76r0rZpwHChBAwXkiE8"
def get_file_content_as_base64(path, urlencoded=False):
    """
    获取文件base64编码
    :param path: 文件路径
    :param urlencoded: 是否对结果进行urlencoded
    :return: base64编码信息
    """
    with open(path, "rb") as f:
        content = base64.b64encode(f.read()).decode("utf8")
        if urlencoded:
            content = urllib.parse.quote_plus(content)
    return content
def get_access_token():
    """
    使用 AK，SK 生成鉴权签名（Access Token）
    :return: access_token，或是None(如果错误)
    """
    url = "https://aip.baidubce.com/oauth/2.0/token"
    params = {"grant_type": "client_credentials", "client_id": API_KEY, "client_secret": SECRET_KEY}
    return str(requests.post(url, params=params).json().get("access_token"))
def creat_users(path, user, user_id):
    url = "https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/add?access_token=" + get_access_token()
    image = get_file_content_as_base64(path, False)
    payload = json.dumps({
        "group_id": user,
        "image": image,
        "image_type": "BASE64",
        "user_id": str(user_id)
    })
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)
    error_msg = json.loads(response.text)["error_msg"]
    print(response.text)
    return error_msg
def test_users(path):
    url = "https://aip.baidubce.com/rest/2.0/face/v3/multi-search?access_token=" + get_access_token()
    image = get_file_content_as_base64(path, False)
    payload = json.dumps({
        "group_id_list": "user",
        "image": image,
        "image_type": "BASE64"
    })
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)
    error_msg = json.loads(response.text)["error_msg"]
    print(response.text)
    return error_msg



    # "user" "user_Jpeg5" "user_Jpeg15" "user_Jpeg25"
user = "user_Jpeg25"
enter_num = 0
for i in range(0,1000):
    path = "/home/WRL/WRL/DeepMIH/HiNet/image/test/test_results/test_experiments5/test4_JPEG25/steg/" + str(i) + ".jpg"
    # test1 test2_JPEG5 test3_JPEG15 test4_JPEG25 test5 test6 test7 test8 test9 test10
    error_msg = creat_users(path, user, i)
    if error_msg == "SUCCESS":
        enter_num+=1
    print(i)
print(enter_num)#20

# protection_success_num = 0
# protection_success = []
# protection_fail_num = 0
# protection_fail = []
# protection_useless_num=0
# protection_useless = []
# for i in range(0, 1000):
#     time.sleep(0.5)
#     # # test1 test2_JPEG5 test3_JPEG15 test4_JPEG25 test5 test6 test7 test8 test9 test10
#     path = "/home/WRL/WRL/DeepMIH/HiNet/image/test/test_results/test_experiments5/test2_JPEG5/secret/" + str(i) + ".jpg"
#     error_msg = test_users(path)
#     if error_msg == "SUCCESS":
#         protection_fail_num +=1
#         protection_fail.append(i)
#     if error_msg == "match user is not found":
#         protection_success_num +=1
#         protection_success.append(i)
#     if error_msg == "Open api daily request limit reached":
#         protection_useless_num +=1
#         protection_useless.append(i)
#     protection_success_rate = protection_success_num/1000
#     print(protection_success_rate)
# print(protection_success_num)
# print(protection_fail_num)
# print(protection_useless_num)
# print(protection_success)
# print(protection_fail)
# print(protection_useless)




