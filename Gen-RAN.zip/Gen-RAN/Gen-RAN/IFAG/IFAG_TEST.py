import torchvision
import numpy as np
import torchvision.transforms as transforms
from IFAG.FAG.FAG_TEST import FAG
from IFAG.FRM.FRM_TEST import FRM

import config as C
transform = transforms.Compose([
    transforms.ToTensor()  # 转换为张量
])
def IFAG(protected_face):
    torchvision.utils.save_image(protected_face, C.IMAGE_TEST_PATH_transit_place + 'transit_place.png')
    anonymization_face_list = FAG(C.IMAGE_TEST_PATH_transit_place)
    anonymization_face = np.copy(anonymization_face_list[0])
    anonymization_face = transform(anonymization_face).unsqueeze(0)  # 添加批次维度
    torchvision.utils.save_image(anonymization_face, C.IMAGE_TEST_PATH_transit_place + 'transit_place.png')

    anonymization_face_enhanced = FRM(C.IMAGE_TEST_PATH_transit_place + 'transit_place.png')
    return anonymization_face, anonymization_face_enhanced
