from IFAG.FAG.detection.detection_api import BaseDetector, RCNNDetector, ImageAnnotation
from IFAG.FAG.detection.build import build_detector
