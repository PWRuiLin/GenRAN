from PIL import Image
import os

# 定义输入文件夹和输出文件夹的路径
input_folder = "输入文件夹路径"
output_folder = "输出文件夹路径"

# 确保输出文件夹存在
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 遍历输入文件夹中的所有文件
for filename in os.listdir(input_folder):
    file_path = os.path.join(input_folder, filename)

    # 检查文件是否为图像文件
    if os.path.isfile(file_path) and filename.endswith(('.jpg', '.jpeg', '.png', '.bmp')):
        # 打开图像文件
        image = Image.open(file_path)

        # 将图像调整为1024x1024大小
        resized_image = image.resize((1024, 1024))

        # 构造输出文件的路径
        output_path = os.path.join(output_folder, filename)

        # 保存调整后的图像到输出文件夹
        resized_image.save(output_path)

