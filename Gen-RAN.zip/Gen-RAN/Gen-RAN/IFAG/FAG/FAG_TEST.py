import matplotlib.pyplot as plt
import numpy as np
import cv2
from IFAG.FAG.detection.detection_api import ImageAnnotation
from IFAG.FAG.inference.anonymizer import Anonymizer, Anonymizer_old
from IFAG.FAG.inference import infer
import typing
import pathlib
import torch
import os
from urllib.parse import urlparse
from IFAG.FAG import torch_utils
# import logger, torch_utils
from IFAG.FAG.config import Config
from IFAG.FAG.inference.infer import load_model_from_checkpoint
# import logger
video_suffix = [".mp4"]
image_suffix = [".jpg", ".jpeg", ".png"]

def batched_iterator(batch, batch_size):
    k = list(batch.keys())[0]
    num_samples = len(batch[k])
    num_batches = int(np.ceil(num_samples / batch_size))
    for idx in range(num_batches):
        start = batch_size * idx
        end = start + batch_size
        yield {
            key: torch_utils.to_cuda(arr[start:end])
            for key, arr in batch.items()
        }

available_models = [
    "fdf128_rcnn512",
    "fdf128_retinanet512",
    "fdf128_retinanet256",
    "fdf128_retinanet128",
    "deep_privacy_V1",
]
config_urls = {
    "fdf128_retinanet512": "https://folk.ntnu.no/haakohu/configs/fdf/retinanet512.json",
    "fdf128_retinanet256": "https://folk.ntnu.no/haakohu/configs/fdf/retinanet256.json",
    "fdf128_retinanet128": "https://folk.ntnu.no/haakohu/configs/fdf/retinanet128.json",
    "fdf128_rcnn512": "https://folk.ntnu.no/haakohu/configs/fdf_512.json",
    "deep_privacy_V1": "https://folk.ntnu.no/haakohu/configs/deep_privacy_v1.json",
}
def get_config(config_url):
    parts = urlparse(config_url)
    cfg_name = os.path.basename(parts.path)
    assert cfg_name is not None
    cfg_path = pathlib.Path(
        torch.hub._get_torch_home(), "deep_privacy_cache", cfg_name)
    cfg_path.parent.mkdir(exist_ok=True, parents=True)
    if not cfg_path.is_file():
        torch.hub.download_url_to_file(config_url, cfg_path)
    assert cfg_path.is_file()
    return Config.fromfile(cfg_path)
def recursive_find_file(folder: pathlib.Path,
                        suffixes: typing.List[str]
                        ) -> typing.List[pathlib.Path]:
    files = []
    for child in folder.iterdir():
        if not child.is_file():
            child_files = recursive_find_file(child, suffixes)
            files.extend(child_files)
        if child.suffix in suffixes:
            files.append(child)
    return files
def get_target_paths(source_paths: typing.List[pathlib.Path],
                     target_path: str,
                     default_dir: pathlib.Path):
    if not target_path is None:
        target_path = pathlib.Path(target_path)
        if len(source_paths) > 1:
            target_path.mkdir(exist_ok=True, parents=True)
            target_paths = []
            for source_path in source_paths:
                target_paths.append(target_path.joinpath(source_path.name))
            return target_paths
        else:
            target_path.parent.mkdir(exist_ok=True)
            return [target_path]
    # logg/er.info(
    #     f"Found no target path. Setting to default output path: {default_dir}")
    default_target_dir = default_dir
    target_path = default_target_dir
    target_path.mkdir(exist_ok=True, parents=True)
    target_paths = []
    for source_path in source_paths:
        if source_path.suffix in video_suffix:
            target_path = default_target_dir.joinpath("anonymized_videos")
        else:
            target_path = default_target_dir.joinpath("anonymized_images")
        target_path = target_path.joinpath(source_path.name)
        os.makedirs(target_path.parent, exist_ok=True)
        target_paths.append(target_path)
    return target_paths
def get_source_files(source_path: str):
    source_path = pathlib.Path(source_path)
    assert source_path.is_file() or source_path.is_dir(),\
        f"Did not find file or directory: {source_path}"
    if source_path.is_file():
        return [source_path]
    relevant_suffixes = image_suffix + video_suffix
    file_paths = recursive_find_file(source_path, relevant_suffixes)
    return file_paths
class DeepPrivacyAnonymizer_old(Anonymizer_old):

    def __init__(self, generator, batch_size, save_debug,
                 fp16_inference: bool,
                 truncation_level=5, **kwargs):
        super().__init__(**kwargs)
        self.inference_imsize = self.cfg.models.max_imsize
        self.batch_size = batch_size
        self.pose_size = self.cfg.models.pose_size
        self.generator = generator
        self.truncation_level = truncation_level
        self.save_debug = save_debug
        self.fp16_inference = fp16_inference
        self.debug_directory = pathlib.Path(".debug", "inference")
        self.debug_directory.mkdir(exist_ok=True, parents=True)

    @torch.no_grad()
    def _get_face(self, batch):
        keys = ["condition", "mask", "landmarks", "z"]
        forward = [batch[k] for k in keys]
#        print([x.shape for x in forward])
        with torch.cuda.amp.autocast(enabled=self.fp16_inference):
            return self.generator(*forward).cpu()

    @torch.no_grad()
    def anonymize_images(self,
                         images: np.ndarray,
                         image_annotations: typing.List[ImageAnnotation]
                         ) -> typing.List[np.ndarray]:
        anonymized_images = []
        for im_idx, image_annotation in enumerate(image_annotations):
            # pre-process
            imsize = self.inference_imsize
            condition = torch.zeros((len(image_annotation), 3, imsize, imsize), dtype=torch.float32)
            mask = torch.zeros((len(image_annotation), 1, imsize, imsize))
            landmarks = torch.empty((len(image_annotation), self.pose_size), dtype=torch.float32)
            for face_idx in range(len(image_annotation)):
                face, mask_ = image_annotation.get_face(face_idx, imsize)
                condition[face_idx] = torch_utils.image_to_torch(face, cuda=False, normalize_img=True)
                mask[face_idx, 0] = torch.from_numpy(mask_).float()
                kp = image_annotation.aligned_keypoint(face_idx)
                landmarks[face_idx] = kp[:, :self.pose_size]
            img = condition
            condition = condition * mask
            z = infer.truncated_z(
                condition, self.cfg.models.generator.z_shape,
                self.truncation_level)
            batches = dict(
                condition=condition,
                mask=mask,
                landmarks=landmarks,
                z=z,
                img=img
            )
            # Inference
            anonymized_faces = np.zeros((
                len(image_annotation), imsize, imsize, 3), dtype=np.float32)
            for idx, batch in enumerate(
                    batched_iterator(batches, self.batch_size)):
                face = self._get_face(batch)
                face = torch_utils.image_to_numpy(
                    face, to_uint8=False, denormalize=True)
                start = idx * self.batch_size
                anonymized_faces[start:start + self.batch_size] = face
            anonymized_image = image_annotation.stitch_faces(anonymized_faces)

            anonymized_images.append(anonymized_image)
            if self.save_debug:
                num_faces = len(batches["condition"])
                for face_idx in range(num_faces):
                    orig_face = torch_utils.image_to_numpy(
                        batches["img"][face_idx], denormalize=True, to_uint8=True)
                    condition = torch_utils.image_to_numpy(
                        batches["condition"][face_idx],
                        denormalize=True, to_uint8=True)
                    fake_face = anonymized_faces[face_idx]
                    fake_face = (fake_face * 255).astype(np.uint8)
                    to_save = np.concatenate(
                        (orig_face, condition, fake_face), axis=1)
                    filepath = self.debug_directory.joinpath(
                        f"im{im_idx}_face{face_idx}.png")
                    cv2.imwrite(str(filepath), to_save[:, :, ::-1])
        return anonymized_images
    def use_mask(self):
        return self.generator.use_mask
def FAG_old(protected_face_paths):
    model_name = available_models[0]
    batch_size: int = 1
    fp16_inference: bool = True
    truncation_level: float = 0
    detection_threshold: float = .1
    opts = None
    config_path = None
    if config_path is None:
        print(config_path)
        assert model_name in available_models,\
            f"{model_name} not in available models: {available_models}"
        cfg = get_config(config_urls[model_name])
    else:
        cfg = Config.fromfile(config_path)
    # logger.info("Loaded model:" + cfg.model_name)
    generator = load_model_from_checkpoint(cfg)
    # logger.info(f"Generator initialized with {torch_utils.number_of_parameters(generator)/1e6:.2f}M parameters")
    cfg.anonymizer.truncation_level = truncation_level
    cfg.anonymizer.batch_size = batch_size
    cfg.anonymizer.fp16_inference = fp16_inference
    cfg.anonymizer.detector_cfg.face_detector_cfg.confidence_threshold = detection_threshold
    cfg.merge_from_str(opts)
    # generator, cfg = cfg, ** cfg.anonymizer
    anonymizer = DeepPrivacyAnonymizer_old(generator, cfg=cfg, **cfg.anonymizer)

    # output_dir = cfg.output_dir
    protected_face_paths = get_source_files(protected_face_paths)
    protected_face_paths = [source_path for source_path in protected_face_paths
                   if source_path.suffix in image_suffix]

    # image_target_paths = []
    # if len(protected_face_paths) > 0:
    #     image_target_paths = get_target_paths(protected_face_paths, 'test_results/', protected_face_paths)
    # assert len(protected_face_paths) == len(image_target_paths)
    # if len(protected_face_paths) > 0:
    protected_face, anonymization_face = anonymizer.anonymize_image_paths(protected_face_paths)
    return anonymization_face, protected_face

# FAG_old("/home/WRL/WRL/RFA-Net/Dataset/experiments/experiment1/1/822.jpg")

class DeepPrivacyAnonymizer(Anonymizer):

    def __init__(self, generator, batch_size, save_debug,
                 fp16_inference: bool,
                 truncation_level=5, **kwargs):
        super().__init__(**kwargs)
        self.inference_imsize = self.cfg.models.max_imsize
        self.batch_size = batch_size
        self.pose_size = self.cfg.models.pose_size
        self.generator = generator
        self.truncation_level = truncation_level
        self.save_debug = save_debug
        self.fp16_inference = fp16_inference
        self.debug_directory = pathlib.Path(".debug", "inference")
        self.debug_directory.mkdir(exist_ok=True, parents=True)

    @torch.no_grad()
    def _get_face(self, batch):
        keys = ["condition", "mask", "landmarks", "z"]
        forward = [batch[k] for k in keys]
#        print([x.shape for x in forward])
        with torch.cuda.amp.autocast(enabled=self.fp16_inference):
            return self.generator(*forward).cpu()

    @torch.no_grad()
    def anonymize_images(self,
                         images: np.ndarray,
                         image_annotations: typing.List[ImageAnnotation]
                         ) -> typing.List[np.ndarray]:
        anonymized_images = []
        for im_idx, image_annotation in enumerate(image_annotations):
            # pre-process
            imsize = self.inference_imsize
            condition = torch.zeros((len(image_annotation), 3, imsize, imsize), dtype=torch.float32)
            mask = torch.zeros((len(image_annotation), 1, imsize, imsize))
            landmarks = torch.empty((len(image_annotation), self.pose_size), dtype=torch.float32)
            for face_idx in range(len(image_annotation)):
                face, mask_ = image_annotation.get_face(face_idx, imsize)
                condition[face_idx] = torch_utils.image_to_torch(face, cuda=False, normalize_img=True)
                mask[face_idx, 0] = torch.from_numpy(mask_).float()
                kp = image_annotation.aligned_keypoint(face_idx)
                landmarks[face_idx] = kp[:, :self.pose_size]
            img = condition
            condition = condition * mask
            z = infer.truncated_z(
                condition, self.cfg.models.generator.z_shape,
                self.truncation_level)
            batches = dict(
                condition=condition,
                mask=mask,
                landmarks=landmarks,
                z=z,
                img=img
            )
            # Inference
            anonymized_faces = np.zeros((
                len(image_annotation), imsize, imsize, 3), dtype=np.float32)
            for idx, batch in enumerate(
                    batched_iterator(batches, self.batch_size)):
                face = self._get_face(batch)
                face = torch_utils.image_to_numpy(
                    face, to_uint8=False, denormalize=True)
                start = idx * self.batch_size
                anonymized_faces[start:start + self.batch_size] = face
            anonymized_image = image_annotation.stitch_faces(anonymized_faces)

            anonymized_images.append(anonymized_image)
            if self.save_debug:
                num_faces = len(batches["condition"])
                for face_idx in range(num_faces):
                    orig_face = torch_utils.image_to_numpy(
                        batches["img"][face_idx], denormalize=True, to_uint8=True)
                    condition = torch_utils.image_to_numpy(
                        batches["condition"][face_idx],
                        denormalize=True, to_uint8=True)
                    fake_face = anonymized_faces[face_idx]
                    fake_face = (fake_face * 255).astype(np.uint8)
                    to_save = np.concatenate(
                        (orig_face, condition, fake_face), axis=1)
                    filepath = self.debug_directory.joinpath(
                        f"im{im_idx}_face{face_idx}.png")
                    cv2.imwrite(str(filepath), to_save[:, :, ::-1])
        return anonymized_images
    def use_mask(self):
        return self.generator.use_mask
def FAG(protected_face_paths):
    model_name = available_models[0]
    batch_size: int = 1
    fp16_inference: bool = True
    truncation_level: float = 0
    detection_threshold: float = .1
    opts = None
    config_path = None
    if config_path is None:
        # print(config_path)
        assert model_name in available_models, \
            f"{model_name} not in available models: {available_models}"
        cfg = get_config(config_urls[model_name])
    else:
        cfg = Config.fromfile(config_path)
    # logger.info("Loaded model:" + cfg.model_name)
    generator = load_model_from_checkpoint(cfg)
    # print(generator)
    # logger.info(f"Generator initialized with {torch_utils.number_of_parameters(generator)/1e6:.2f}M parameters")
    cfg.anonymizer.truncation_level = truncation_level
    cfg.anonymizer.batch_size = batch_size
    cfg.anonymizer.fp16_inference = fp16_inference
    cfg.anonymizer.detector_cfg.face_detector_cfg.confidence_threshold = detection_threshold
    cfg.merge_from_str(opts)

    # generator, cfg = cfg, ** cfg.anonymizer
    anonymizer = DeepPrivacyAnonymizer(generator, cfg=cfg, **cfg.anonymizer)
    # output_dir = cfg.output_dir
    protected_face_paths = get_source_files(protected_face_paths)

    protected_face_path = [source_path for source_path in protected_face_paths
                   if source_path.suffix in image_suffix]
    # image_target_paths = []
    # if len(image_paths) > 0:
    #     image_target_paths = get_target_paths(image_paths, 'test_results/', output_dir)
    # assert len(image_paths) == len(image_target_paths)
    # if len(image_paths) > 0:
    protected_face, anonymization_face = anonymizer.anonymize_image_paths(protected_face_path)
    return anonymization_face



# if __name__ == "__main__":
#     FAG()


