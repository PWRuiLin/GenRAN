from IFAG.FAG.utils import Registry

CRITERION_REGISTRY = Registry("CRITERION")
