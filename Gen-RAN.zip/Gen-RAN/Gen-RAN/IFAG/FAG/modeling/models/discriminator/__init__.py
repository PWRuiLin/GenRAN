from .original import Discriminator
