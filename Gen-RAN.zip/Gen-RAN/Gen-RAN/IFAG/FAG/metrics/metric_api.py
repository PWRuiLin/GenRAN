import numpy as np
import skimage
import skimage.measure
import torch
import tqdm
import multiprocessing
try:
    from skimage.measure import compare_ssim, compare_psnr
except ImportError:
    from skimage.metrics import structural_similarity as compare_ssim
    from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from IFAG.FAG.metrics.perceptual_similarity import PerceptualLoss
from IFAG.FAG import torch_utils
from IFAG.FAG.metrics.fid_pytorch import fid as fid_api
from typing import List, Dict


def compute_metrics(
        images1: np.ndarray, images2: np.ndarray,
        metrics: List[str]) -> Dict[str, float]:
    results = {}
    METRICS = {
        "l1": l1,
        "l2": l2,
        "ssim": ssim,
        "psnr": psnr,
        "lpips": lpips,
        "fid": fid
    }
    for metric in metrics:
        func = METRICS[metric]
        results[metric] = func(images1, images2)
    return results


def check_shape(images1: np.ndarray, images2: np.ndarray):
    assert len(images1.shape) == 4
    assert images1.shape == images2.shape
    assert images1.dtype == np.float32
    assert images2.dtype == np.float32
    assert images1.max() <= 1 and images1.min() >= 0
    assert images2.max() <= 1 and images2.min() >= 0


def l2(images1: np.ndarray, images2: np.ndarray):
    check_shape(images1, images2)
    difference = (images1 - images2)**2
    rmse = difference.reshape(difference.shape[0], -1)
    rmse = rmse.mean(axis=1) ** 0.5
    return rmse.mean()


def l1(images1: np.ndarray, images2: np.ndarray):
    check_shape(images1, images2)
    difference = abs(images1 - images2)
    return difference.mean()


def ssim(images1: np.ndarray, images2: np.ndarray):
    check_shape(images1, images2)
    mean_ssim = 0
    with multiprocessing.Pool(multiprocessing.cpu_count()) as pool:
        jobs = []
        for img1, img2 in zip(images1, images2):
            s = pool.apply_async(
                compare_ssim, (img1, img2),
                dict(
                    data_range=1, multichannel=True, win_size=11,
                    gaussian_weights=True, sigma=1.5,
                    use_sample_covariance=False, K1=0.01 ** 2, K2=0.03 ** 2))
            jobs.append(s)
        for job in tqdm.tqdm(jobs):
            mean_ssim += job.get()
    return mean_ssim / images1.shape[0]


def psnr(images1: np.ndarray, images2: np.ndarray):
    check_shape(images1, images2)
    mean_psnr = 0
    for img1, img2 in zip(images1, images2):
        s = compare_psnr(
            img1, img2, data_range=1)
        mean_psnr += s.mean()
    return mean_psnr / images1.shape[0]


def lpips(images1: np.ndarray, images2: np.ndarray,
          batch_size: int = 64,
          metric_type: str = "net-lin",
          reduce=True):
    assert metric_type in ["net-lin", "l2", "ssim", ]

    check_shape(images1, images2)
    n_batches = int(np.ceil(images1.shape[0] / batch_size))
    model = PerceptualLoss(
        model='net-lin', net='alex', use_gpu=torch.cuda.is_available())
    distances = np.zeros((images1.shape[0]), dtype=np.float32)
    for i in range(n_batches):
        start_idx = i * batch_size
        end_idx = (i + 1) * batch_size
        im1 = images1[start_idx:end_idx]
        im2 = images2[start_idx:end_idx]
        im1 = torch_utils.image_to_torch(im1, normalize_img=True)
        im2 = torch_utils.image_to_torch(im2, normalize_img=True)
        with torch.no_grad():
            dists = model(im1, im2, normalize=False).cpu().numpy().squeeze()
        distances[start_idx:end_idx] = dists
    if reduce:

        return distances.mean()
    assert batch_size == 1
    return distances


def fid(images1: np.ndarray, images2: np.ndarray,
        batch_size: int = 64):
    check_shape(images1, images2)
    fid = fid_api.calculate_fid(
        images1, images2, batch_size=batch_size, dims=2048)
    return fid


def compute_all_metrics(images1: np.ndarray, images2: np.ndarray):
    metrics = {}
    metrics["L1"] = l1(images1, images2)
    metrics["L2"] = l2(images1, images2)
    metrics["PSNR"] = psnr(images1, images2)
    # metrics["SSIM"] = ssim(images1, images2)
    # metrics["LPIPS"] = lpips(images1, images2)
    return metrics


def print_all_metrics(images1: np.ndarray, images2: np.ndarray):
    metrics = compute_all_metrics(images1, images2)
    for m, v in metrics.items():
        print(f"{m}: {v}")

def compute_API(images1: np.ndarray, images2: np.ndarray):
    metrics = {}
    metrics["API"] = fid(images1, images2, 1)
    return metrics
def print_API(images1: np.ndarray, images2: np.ndarray):
    metrics = compute_API(images1, images2)
    for m, v in metrics.items():
        print(f"{m}: {v}")
if __name__ == "__main__":
    import argparse
    import pathlib
    import file_util
    parser = argparse.ArgumentParser()
    parser.add_argument("--path1", default=r"/home/WRL/WRL/DeepPrivacy/Reversible_Model/image/secret/")
    parser.add_argument("--path2", default=r"/home/WRL/WRL/DeepPrivacy/Reversible_Model/image/cover/")
    args = parser.parse_args()
    path1 = pathlib.Path(args.path1)
    path2 = pathlib.Path(args.path2)
    filepaths1 = file_util.find_all_files(path1)
    filepaths2 = file_util.find_matching_files(path2, filepaths1)
    images1 = file_util.read_images(filepaths1)
    images2 = file_util.read_images(filepaths2)
    # print_all_metrics(images1, images2)
    print_API(images1, images2)


    # folder_GT = './image/secret/'
    # folder_Gen = './image/steg/'
    # crop_border = 1
    # suffix = '_secret_rev'  # suffix for Gen images
    # test_Y = False  # True: test Y channel only; False: test RGB channels
    #
    # PSNR_all = []
    # SSIM_all = []
    # img_list = sorted(glob.glob(folder_GT + '/*.png'))
    # img_list = natsorted(img_list)
    #
    # if test_Y:
    #     print('Testing Y channel.')
    # else:
    #     print('Testing RGB channels.')
    #
    # for i, img_path in enumerate(img_list):
    #     base_name = os.path.splitext(os.path.basename(img_path))[0]
    #     # base_name = base_name[:5]
    #     im_GT = cv2.imread(img_path) / 255.
    #     # print(base_name)
    #     # print(img_path)
    #     # print(os.path.join(folder_Gen, base_name + '.png'))
    #     im_Gen = cv2.imread(os.path.join(folder_Gen, base_name + '.png')) / 255.
    #
    #
    #     if test_Y and im_GT.shape[2] == 3:  # evaluate on Y channel in YCbCr color space
    #         im_GT_in = bgr2ycbcr(im_GT)
    #         im_Gen_in = bgr2ycbcr(im_Gen)
    #     else:
    #         im_GT_in = im_GT
    #         im_Gen_in = im_Gen
    #
    #
    #     # calculate PSNR and SSIM
    #     PSNR = calculate_psnr(im_GT_in * 255, im_Gen_in * 255)
    #
    #     SSIM = calculate_ssim(im_GT_in * 255, im_Gen_in * 255)
    #     print('{:3d} - {:25}. \tPSNR: {:.6f} dB, \tSSIM: {:.6f}'.format(
    #         i + 1, base_name, PSNR, SSIM))
    #     PSNR_all.append(PSNR)
    #     SSIM_all.append(SSIM)
    # print('Average: PSNR: {:.6f} dB, SSIM: {:.6f}'.format(
    #     sum(PSNR_all) / len(PSNR_all),
    #     sum(SSIM_all) / len(SSIM_all)))
    #
    # with open('1.txt', 'w') as f:
    #     f.write(str(PSNR_all))
